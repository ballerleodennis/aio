#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Watch-Modus: beobachtet chains.json und chains/, reagiert auf neue Chains
mit Auto-Fetch, Auto-Index und Bundle-/Manifest-Neubau. Fingerprints landen
in reports/watch-state.json, Aenderungen in reports/watch-<ts>.md.
"""
import hashlib, json, os, threading, time
from datetime import datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(ROOT, "reports")
OFFLINE = os.path.join(REPORTS, "offline")
STATE_FILE = os.path.join(REPORTS, "watch-state.json")
CHAINS_DIR = os.path.join(ROOT, "chains")
DB_FILE = os.path.join(ROOT, "chains.json")

STATE = {"thread": None, "stop": False, "ctx": None, "interval": 2.5,
         "pending": set(), "last_rebuild": 0.0, "fingerprint": "",
         "changes": 0, "last_change": None, "new_chains": [], "errors": []}


# ------------------------------------------------------------------ Fingerprint
def _md5(p):
    h = hashlib.md5()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def snapshot():
    snap = {}
    for base, _, files in os.walk(CHAINS_DIR):
        for f in files:
            p = os.path.join(base, f)
            try:
                st = os.stat(p)
                snap[os.path.relpath(p, ROOT)] = (int(st.st_mtime), st.st_size)
            except OSError:
                pass
    if os.path.isfile(DB_FILE):
        st = os.stat(DB_FILE)
        snap["chains.json"] = (int(st.st_mtime), st.st_size)
    return snap


def fingerprint(snap):
    body = "\n".join(f"{k}:{v[1]}" for k, v in sorted(snap.items()))
    return hashlib.sha256(body.encode()).hexdigest()[:16]


# ------------------------------------------------------------------------ Laden
def _load_state():
    try:
        d = json.load(open(STATE_FILE))
        STATE["fingerprint"] = d.get("fingerprint", "")
        STATE["new_chains"] = d.get("new_chains", [])[-40:]
    except Exception:
        pass


def _save_state(snap):
    os.makedirs(OFFLINE, exist_ok=True)
    json.dump({"fingerprint": fingerprint(snap), "new_chains": STATE["new_chains"][-40:],
               "last_change": STATE["last_change"], "changes": STATE["changes"]},
              open(STATE_FILE, "w"), indent=2)


# ------------------------------------------------------------------------ Diff
def diff(old, new):
    added = [k for k in new if k not in old]
    removed = [k for k in old if k not in new]
    changed = [k for k in new if k in old and new[k] != old[k]]
    return added, removed, changed


# ------------------------------------------------------------------ Neue Chains
def _handle_new_chains(ctx, emit):
    db = ctx["load_db"]()
    known = {c["id"] for c in db.get("chains", [])}
    handled = set(STATE.get("_known") or [])
    fresh = [c for c in db.get("chains", []) if c["id"] not in handled]

    for ch in fresh:
        cid = ch["id"]
        emit("watch-new", f"neue Chain erkannt: {cid}", chain=cid)
        STATE["new_chains"].append({"id": cid, "t": time.time()})

        if ch.get("repo") and not ctx["chain_files"](cid):
            ok = ctx["fetch_repo"](ch["repo"], cid, ch.get("branch"))
            emit("watch", f"{cid}: fetch {'ok' if ok else 'fehlgeschlagen'}", chain=cid)
            if not ok:
                STATE["errors"].append(f"{cid}: fetch")
                continue

        files = ctx["chain_files"](cid)
        if files and not ch.get("order"):
            guess = ctx["guess_entry"](cid)
            core = [f for f in guess if not f.endswith(("exploit.js", "afterglow.js",
                                                        "jb.js", "index.html"))]
            entry = next((f for f in guess if f.endswith(("exploit.js", "afterglow.js"))), None)
            ch["order"] = (core[:4] + ([entry] if entry else guess[:1])) or files[:5]
            emit("watch", f"{cid}: Lade-Reihenfolge gesetzt ({len(ch['order'])} Dateien)")
        if "14.00" in (ch.get("firmware") or []) and "test_14_02" not in ch:
            ch["test_14_02"] = True
            emit("watch", f"{cid}: auf 14.02-Testpfad gesetzt")
        STATE["pending"].update(ch.get("firmware") or [])
        STATE["pending"].add("14.02")

    if fresh:
        ctx["save_db"](db)
    STATE["_known"] = list(known | {c["id"] for c in fresh})


# ------------------------------------------------------------------- Neubau
def _rebuild(ctx, emit):
    if not STATE["pending"]:
        return
    if time.time() - STATE["last_rebuild"] < 10:
        return
    fws = sorted(STATE["pending"])
    STATE["pending"].clear()
    STATE["last_rebuild"] = time.time()
    os.makedirs(OFFLINE, exist_ok=True)

    for fw in fws:
        try:
            body, ver = ctx["build_manifest"](fw)
            open(os.path.join(ROOT, "cache.appcache"), "w", encoding="utf-8").write(body)
            open(os.path.join(OFFLINE, f"cache-fw{fw}.appcache"), "w",
                 encoding="utf-8").write(body)
            blob = ctx["offline_bundle"](fw)
            open(os.path.join(OFFLINE, f"offline-fw{fw}.zip"), "wb").write(blob)
            emit("watch-rebuild", f"fw{fw}: Manifest v{ver} + Bundle ({len(blob)} B)")
        except Exception as e:
            emit("watch-err", f"fw{fw}: {e}")
            STATE["errors"].append(f"{fw}: {e}")
    STATE["errors"] = STATE["errors"][-20:]


# ---------------------------------------------------------------------- Loop
def _loop():
    ctx, emit = STATE["ctx"], STATE["ctx"]["emit"]
    _load_state()
    snap = snapshot()
    STATE["_known"] = [c["id"] for c in ctx["load_db"]().get("chains", [])]
    emit("watch", f"aktiv, {len(snap)} Objekte ueberwacht")

    while not STATE["stop"]:
        time.sleep(STATE["interval"])
        new = snapshot()
        added, removed, changed = diff(snap, new)
        if not (added or removed or changed):
            continue

        STATE["changes"] += 1
        STATE["last_change"] = time.time()
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        emit("watch", f"Aenderung: +{len(added)} -{len(removed)} ~{len(changed)}")

        md = [f"# Watch {stamp}", "", f"- neu: {len(added)}", f"- weg: {len(removed)}",
              f"- geaendert: {len(changed)}", ""]
        md += [f"+ {a}" for a in added[:80]] + [f"- {r}" for r in removed[:80]]
        md += [f"~ {c}" for c in changed[:80]]
        try:
            open(os.path.join(REPORTS, f"watch-{stamp}.md"), "w",
                 encoding="utf-8").write("\n".join(md))
        except OSError:
            pass

        try:
            if "chains.json" in added + changed:
                _handle_new_chains(ctx, emit)
            db = ctx["load_db"]()
            for ch in db.get("chains", []):
                STATE["pending"].update(ch.get("firmware") or [])
            if added or changed:
                STATE["pending"].add("14.02")
            _rebuild(ctx, emit)
        except Exception as e:
            emit("watch-err", f"loop: {e}")

        snap = new
        _save_state(snap)


# -------------------------------------------------------------------- Public
def start(ctx, interval=2.5):
    if STATE["thread"] and STATE["thread"].is_alive():
        return False
    STATE.update(ctx=ctx, stop=False, interval=interval)
    STATE["thread"] = threading.Thread(target=_loop, daemon=True)
    STATE["thread"].start()
    return True


def stop():
    STATE["stop"] = True
    return True


def info():
    return {"active": bool(STATE["thread"] and STATE["thread"].is_alive()),
            "interval": STATE["interval"], "pending": sorted(STATE["pending"]),
            "changes": STATE["changes"], "last_change": STATE["last_change"],
            "new_chains": STATE["new_chains"][-10:],
            "errors": STATE["errors"][-5:],
            "last_rebuild": STATE["last_rebuild"] or None}


def force(*fws):
    STATE["pending"].update(fws or ["14.02"])
    STATE["last_rebuild"] = 0.0
    return sorted(STATE["pending"])