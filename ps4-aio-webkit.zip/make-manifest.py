#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Baut cache.appcache pro Firmware. CLI: python make-manifest.py 14.02"""
import hashlib, json, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "cache.appcache")
BASE = ["/", "/index.html", "/exploit.html", "/api/status"]


def _h(p):
    try:
        return hashlib.sha1(open(p, "rb").read()).hexdigest()[:12]
    except OSError:
        return "x"


def build(fw):
    try:
        db = json.load(open(os.path.join(ROOT, "chains.json"), encoding="utf-8"))
    except Exception:
        db = {"chains": []}

    files = list(BASE)
    sig = []
    for ch in db.get("chains", []):
        if fw not in (ch.get("firmware") or []) and not ch.get("test_14_02"):
            continue
        d = os.path.join(ROOT, "chains", ch["id"])
        if not os.path.isdir(d):
            continue
        for base, _, fs in os.walk(d):
            for f in fs:
                rel = os.path.relpath(os.path.join(base, f), ROOT).replace("\\", "/")
                files.append("/" + rel)
                sig.append(_h(os.path.join(base, f)))

    ver = hashlib.sha1(("".join(sorted(sig)) + fw).encode()).hexdigest()[:16]
    lines = [f"CACHE MANIFEST", f"# v{ver} fw{fw}", ""]
    lines += sorted(set(files))
    lines += ["", "NETWORK:", "*", "", "FALLBACK:", "/exploit.html /exploit.html"]
    return "\n".join(lines) + "\n", ver


def write(fw):
    body, ver = build(fw)
    open(OUT, "w", encoding="utf-8").write(body)
    return OUT, ver


if __name__ == "__main__":
    fw = sys.argv[1] if len(sys.argv) > 1 else "14.02"
    p, v = write(fw)
    print(f"{p} geschrieben (v{v}, fw{fw})")