#requires -Version 5.1
<#
    repair-ps4-aio.ps1

    Repariert:  ModuleNotFoundError: No module named 'make_manifest'
                beim Start von ps4_aio_server.py

    Ablauf:
      1. Projektordner + ps4_aio_server.py pruefen
      2. make_manifest.py im Umfeld suchen -> zurueckkopieren
      3. falls nirgends vorhanden: Platzhalter passend zu den
         tatsaechlich referenzierten Funktionsnamen erzeugen
      4. sys.path-Bootstrap + abgesicherten Import einsetzen (idempotent, mit .bak)
      5. Launcher (.bat/.cmd) auf cd /d "%~dp0" umstellen
      6. Import + Syntax verifizieren

    Aufruf:
      powershell -ExecutionPolicy Bypass -File .\repair-ps4-aio.ps1
      powershell -ExecutionPolicy Bypass -File .\repair-ps4-aio.ps1 -Root "D:\ps4-aio"
#>
[CmdletBinding()]
param(
    [string]$Root = $PSScriptRoot,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$script:Fail = 0

function Step($m) { Write-Host "`n[*] $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "    [ok]   $m" -ForegroundColor Green }
function Warn($m) { Write-Host "    [warn] $m" -ForegroundColor Yellow }
function Bad($m)  { Write-Host "    [fail] $m" -ForegroundColor Red; $script:Fail++ }

function Read-TextFile([string]$Path) {
    [System.IO.File]::ReadAllText($Path)
}
function Write-TextFile([string]$Path, [string]$Text) {
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

# ---------------------------------------------------------------- 1. Projekt
Step "Projektordner pruefen"
if (-not $Root) { Bad "Kein -Root angegeben und `$PSScriptRoot leer."; exit 1 }
if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
    Bad "Ordner existiert nicht: $Root"; exit 1
}
$Root = (Resolve-Path -LiteralPath $Root).Path
Ok "Projekt: $Root"

$Server = Join-Path $Root 'ps4_aio_server.py'
if (-not (Test-Path -LiteralPath $Server -PathType Leaf)) {
    Bad "ps4_aio_server.py nicht gefunden in $Root"; exit 1
}
Ok "Server-Datei gefunden"

$Py = $null
foreach ($cand in @('python', 'py')) {
    $cmd = Get-Command $cand -ErrorAction SilentlyContinue
    if ($cmd) { $Py = $cmd.Source; break }
}
if ($Py) { Ok "Python: $Py" } else { Warn "Kein Python im PATH - Verifikation wird uebersprungen" }

# --------------------------------------------------- 2. Modul suchen / holen
Step "make_manifest.py lokalisieren"
$Target = Join-Path $Root 'make_manifest.py'
$NeedStub = $false

if (Test-Path -LiteralPath $Target -PathType Leaf) {
    Ok "liegt bereits im Projektordner"
}
else {
    Warn "fehlt im Projektordner - suche im Umfeld"
    $searchDirs = @(
        (Split-Path -Parent $Root),
        (Join-Path (Split-Path -Parent $Root) 'ps4-aio'),
        (Join-Path $Root 'lib'),
        (Join-Path $Root 'tools'),
        (Join-Path $Root 'src'),
        (Join-Path $Root 'scripts')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) } | Select-Object -Unique

    $found = $null
    foreach ($d in $searchDirs) {
        $hit = Get-ChildItem -LiteralPath $d -Filter 'make_manifest.py' -File -Recurse -Depth 2 -ErrorAction SilentlyContinue |
               Where-Object { $_.FullName -ne $Target } | Select-Object -First 1
        if ($hit) { $found = $hit; break }
    }

    if ($found) {
        Copy-Item -LiteralPath $found.FullName -Destination $Target -Force
        Ok "zurueckgeholt aus: $($found.FullName)"
    }
    else {
        Warn "nirgends gefunden - Platzhalter wird erzeugt"
        $NeedStub = $true
    }
}

# ------------------------------------------------------------ 3. Platzhalter
if ($NeedStub) {
    Step "Platzhalter erzeugen"

    $src = Read-TextFile $Server
    $attrs = [regex]::Matches($src, 'make_manifest\.([A-Za-z_]\w*)') |
             ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique
    if ($attrs) { Warn ("referenzierte Namen: " + ($attrs -join ', ')) }
    else { Warn "keine make_manifest.<name>-Aufrufe gefunden - nehme build/main an" }

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('# make_manifest.py - Platzhalter, erzeugt von repair-ps4-aio.ps1')
    $lines.Add('# Original ersetzen, sobald wieder verfuegbar.')
    $lines.Add('import hashlib, json, os')
    $lines.Add('')
    $lines.Add('MANIFEST = "manifest.json"')
    $lines.Add('')
    $lines.Add('def build(base="."):')
    $lines.Add('    entries = []')
    $lines.Add('    for name in sorted(os.listdir(base)):')
    $lines.Add('        p = os.path.join(base, name)')
    $lines.Add('        if not os.path.isfile(p) or name == MANIFEST:')
    $lines.Add('            continue')
    $lines.Add('        with open(p, "rb") as fh:')
    $lines.Add('            entries.append({"name": name,')
    $lines.Add('                            "size": os.path.getsize(p),')
    $lines.Add('                            "sha256": hashlib.sha256(fh.read()).hexdigest()})')
    $lines.Add('    data = {"files": entries}')
    $lines.Add('    with open(os.path.join(base, MANIFEST), "w") as fh:')
    $lines.Add('        json.dump(data, fh, indent=2)')
    $lines.Add('    return data')
    $lines.Add('')
    foreach ($a in $attrs) {
        if ($a -eq 'build') { continue }
        $lines.Add("def $a(base=`".`"):")
        $lines.Add('    return build(base)')
        $lines.Add('')
    }
    $lines.Add('if __name__ == "__main__":')
    $lines.Add('    print(build())')

    Write-TextFile $Target ($lines -join "`r`n")
    Ok "Platzhalter geschrieben: $Target"
}

# ------------------------------------------------------- 4. Server patchen
Step "ps4_aio_server.py patchen"

$text  = Read-TextFile $Server
$crlf  = $text -match "`r`n"
$nl    = if ($crlf) { "`r`n" } else { "`n" }
$lines = [System.Collections.Generic.List[string]]($text -split "`r?`n")

$markerStart = '# >>> PS4-AIO sys.path bootstrap'
$markerEnd   = '# <<< PS4-AIO sys.path bootstrap'
$already     = ($lines | Where-Object { $_ -like "$markerStart*" }).Count -gt 0

$importIdx = -1
$importPat = '^\s*(import\s+make_manifest\b|from\s+make_manifest\s+import\b)'
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match $importPat) { $importIdx = $i; break }
}

if ($importIdx -lt 0) {
    Warn "keine make_manifest-Importzeile gefunden - evtl. schon anders geloest"
}
elseif ($already -and -not $Force) {
    Ok "Bootstrap-Marker bereits vorhanden - Patch uebersprungen (-Force erzwingt)"
}
else {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $bak = "$Server.$stamp.bak"
    Copy-Item -LiteralPath $Server -Destination $bak -Force
    Ok "Backup: $(Split-Path -Leaf $bak)"

    $bootstrap = @(
        $markerStart + ' (repair-ps4-aio.ps1)',
        'import os as _os, sys as _sys',
        '_HERE = _os.path.dirname(_os.path.abspath(__file__))',
        'for _p in (_HERE, _os.path.join(_HERE, "lib"), _os.path.join(_HERE, "tools"),',
        '           _os.path.join(_HERE, "src"), _os.path.dirname(_HERE)):',
        '    if _os.path.isdir(_p) and _p not in _sys.path:',
        '        _sys.path.insert(0, _p)',
        $markerEnd
    )

    $orig = $lines[$importIdx]
    $indent = ([regex]::Match($orig, '^\s*')).Value
    $mods = $null
    if ($orig -match '^from\s+make_manifest\s+import\s+(.+)$') {
        $mods = ($Matches[1] -split ',' | ForEach-Object { $_.Trim() }) -join ', '
        $guard = @(
            'try:',
            "${indent}    from make_manifest import $mods",
            'except ModuleNotFoundError:',
            "${indent}    make_manifest = None",
            "${indent}    $mods = " + (($mods -split ', ' | ForEach-Object { 'None' }) -join ', '),
            "${indent}    print(`"[warn] make_manifest fehlt - Manifest-Funktionen deaktiviert`")"
        )
    }
    else {
        $guard = @(
            'try:',
            "${indent}    import make_manifest",
            'except ModuleNotFoundError:',
            "${indent}    make_manifest = None",
            "${indent}    print(`"[warn] make_manifest fehlt - Manifest-Funktionen deaktiviert`")"
        )
    }

    $lines.RemoveAt($importIdx)
    $lines.InsertRange($importIdx, [string[]]$guard)
    $lines.InsertRange($importIdx, [string[]]$bootstrap)

    Write-TextFile $Server ($lines -join $nl)
    Ok "Bootstrap + abgesicherter Import eingesetzt (Zeile $($importIdx + 1))"

    if ($null -ne $mods) {
        Warn "pruefe Aufrufstellen: $mods sind bei fehlendem Modul None"
    }
}

# ---------------------------------------------------------- 5. Launcher fixen
Step "Launcher pruefen"
$launchers = Get-ChildItem -LiteralPath $Root -Include '*.bat', '*.cmd' -File -ErrorAction SilentlyContinue
if (-not $launchers) { Warn "kein .bat/.cmd gefunden - uebersprungen" }
foreach ($l in $launchers) {
    $c = Read-TextFile $l.FullName
    if ($c -match '(?im)^\s*cd\s+/d\s+"?%~dp0') { Ok "$($l.Name): cd bereits vorhanden"; continue }
    Copy-Item -LiteralPath $l.FullName -Destination "$($l.FullName).bak" -Force
    Write-TextFile $l.FullName ("cd /d `"%~dp0`"" + "`r`n" + $c)
    Ok "$($l.Name): cd /d eingefuegt (Backup: $($l.Name).bak)"
}

# ------------------------------------------------------------ 6. Verifikation
Step "Verifikation"
if (-not $Py) { Warn "ohne Python keine Verifikation" }
else {
    Push-Location $Root
    try {
        $out = & $Py -c "import make_manifest; print(make_manifest.__file__)" 2>&1
        if ($LASTEXITCODE -eq 0) { Ok "Import: $out" } else { Bad "Import fehlgeschlagen: $out" }

        $out2 = & $Py -m py_compile ps4_aio_server.py 2>&1
        if ($LASTEXITCODE -eq 0) { Ok "Syntax: ps4_aio_server.py kompiliert" }
        else { Bad "Syntaxfehler: $out2" }

        $out3 = & $Py -c "import ast,sys; t=ast.parse(open('ps4_aio_server.py',encoding='utf-8').read()); print(len(t.body))" 2>&1
        if ($LASTEXITCODE -eq 0) { Ok "AST: $out3 Top-Level-Statements" }
    }
    finally { Pop-Location }
}

Step "Ergebnis"
if ($script:Fail -eq 0) {
    Write-Host "    Reparatur abgeschlossen. Starte den Server und waehle erneut Option 3." -ForegroundColor Green
    Write-Host "    Bei Option 3 zuerst Option 4 (Zertifikat) laufen lassen, falls 8443 noch keins hat." -ForegroundColor DarkGray
    exit 0
} else {
    Write-Host "    $($script:Fail) Punkt(e) offen - Ausgabe oben pruefen." -ForegroundColor Red
    exit 1
}