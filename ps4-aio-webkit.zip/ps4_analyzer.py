#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Automatische Chain-/Offset-/Exploit-Suche.
Zieht Kandidaten-Repos, indiziert Firmware-Tabellen, extrahiert Offset-Kandidaten,
schreibt Report und traegt neue Ziele in chains.json ein.

    python ps4_analyzer.py
"""
import json, os, re, time
from datetime import datetime
from urllib.parse import quote
from urllib.request import urlopen, Request

ROOT = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(ROOT, "reports")
os.makedirs(REPORTS, exist_ok=True)

QUERIES = [
    "ps4 webkit exploit firmware 14.02",
    "ps4 14.00 kernel exploit afterglow",
    "ps4 slopkit exploit",
    "ps4 exploit host offsets",
    "ps4 lapse kernel exploit",
    "ps4 netctrl kernel exploit",
    "ps4 webkit host goldhen",
]

FW_RE   = re.compile(r"\b(?:1[0-4]|[4-9])\.\d{2}\b")
OFF_RE  = re.compile(r"0x[0-9A-Fa-f]{6,16}")
TBL_RE  = re.compile(r"(PATCH_TABLE|BOOTSTRAP_TABLE|OFFSETS?|offsets\s*=|FW_\w+|firmware\s*[:=])", re.I)
ENTRY_RE = re.compile(r"(exploit|afterglow|lapse|netctrl|relapse|slopkit|psfree|hen|jb)\.js$", re.I)


def _get(url, timeout=30):
    req = Request(url, headers={"User-Agent": "ps4-aio-analyzer/1.0",
                               "Accept": "application/vnd.github+json"})
    return urlopen(req, timeout=timeout).read()


def search_repos(query):
    url = ("https://api.github.com/search/repositories?q=" + quote(query) +
           "&sort=updated&order=desc&per_page=8")
    try:
        data = json.loads(_get(url))
    except Exception as e:
        return [], str(e)
    out = []
    for r in data.get("items", []):
        out.append({"repo": r["full_name"], "stars": r["stargazers_count"],
                    "updated": r["updated_at"], "desc": (r.get("description") or "")[:120]})
    return out, None


def index_local_chain(cid):
    """Sucht in bereits entpackten Chains nach FW-Tabellen und Offsets."""
    d = os.path.join(ROOT, "chains", cid)
    res = {"firmwares": set(), "offset_files": [], "entries": [], "tables": []}
    if not os.path.isdir(d):
        return res
    for base, _, files in os.walk(d):
        for f in files:
            if not f.endswith((".js", ".json")):
                continue
            p = os.path.join(base, f)
            try:
                txt = open(p, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            rel = os.path.relpath(p, d)
            fws = set(FW_RE.findall(txt))
            offs = OFF_RE.findall(txt)
            if fws:
                res["firmwares"] |= fws
            if len(offs) > 40:
                res["offset_files"].append({"file": rel, "offsets": len(offs),
                                            "sample": offs[:6]})
            if TBL_RE.search(txt):
                res["tables"].append(rel)
            if ENTRY_RE.search(f):
                res["entries"].append(rel)
    return res


def run(emit=print):
    db_path = os.path.join(ROOT, "chains.json")
    try:
        db = json.load(open(db_path, encoding="utf-8"))
    except Exception:
        db = {"chains": [], "discovered": []}

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    md = [f"# Analyse {stamp}", ""]
    offset_report = {}

    emit("analyze", "Starte Repo-Suche")
    seen = {c.get("repo") for c in db.get("chains", [])}
    new = []
    for q in QUERIES:
        hits, err = search_repos(q)
        if err:
            emit("error", f"search '{q}': {err}")
            continue
        md.append(f"## Query `{q}`")
        for h in hits:
            md.append(f"- {h['repo']}  ⭐{h['stars']}  upd {h['updated']}  — {h['desc']}")
            if h["repo"] not in seen:
                new.append(h["repo"])
                seen.add(h["repo"])
        md.append("")
        time.sleep(2.2)   # unauthenticated rate limit
        emit("analyze", f"'{q}': {len(hits)} Treffer")

    md.append("## Lokale Chain-Indizes")
    for c in db.get("chains", []):
        cid = c["id"]
        res = index_local_chain(cid)
        md.append(f"### {cid}")
        md.append(f"- Firmwares im Code: {', '.join(sorted(res['firmwares'])) or '—'}")
        md.append(f"- Offset-lastige Dateien: {len(res['offset_files'])}")
        md.append(f"- Tabellen-Kandidaten: {', '.join(res['tables'][:8]) or '—'}")
        md.append(f"- Entry-Kandidaten: {', '.join(res['entries'][:8]) or '—'}")
        md.append("")
        offset_report[cid] = {"firmwares": sorted(res["firmwares"]),
                              "offset_files": res["offset_files"][:20]}
        fws = sorted(res["firmwares"])
        if fws:
            c["firmware_seen"] = fws
        if res["entries"] and not c.get("order"):
            c["order"] = sorted(set(res["entries"]))[:8]

    db["discovered"] = sorted(set(db.get("discovered", []) + new))[-200:]
    db["last_analysis"] = stamp
    json.dump(db, open(db_path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    md += ["## Neue Kandidaten-Repos", ""] + [f"- {r}" for r in new[:60]]
    md += ["", "---", "14.02-Hinweis: oeffentliche Chains enden bei 14.00. "
           "Treffer mit `14.02` im Code pruefen und als eigenen Chain-Eintrag testen."]

    p = os.path.join(REPORTS, f"analysis-{stamp}.md")
    open(p, "w", encoding="utf-8").write("\n".join(md))
    json.dump(offset_report, open(os.path.join(REPORTS, f"offsets-{stamp}.json"), "w"),
              indent=2)
    emit("analyze", f"Report: reports/analysis-{stamp}.md")
    return p


if __name__ == "__main__":
    run(lambda k, m, **e: print(f"[{k}] {m}"))