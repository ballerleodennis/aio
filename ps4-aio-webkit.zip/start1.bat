@echo off
setlocal
cd /d "%~dp0"
title PS4 AIO Server
if not exist logs md logs
if not exist payloads md payloads
if not exist chains md chains
if not exist reports md reports
echo.
echo  PS4 AIO - startet auf Port 8000
echo  PS4-Browser: http://DEINE-IP:8000/exploit.html
echo.
python --version >nul 2>&1 || (echo Python fehlt im PATH! & pause & exit /b 1)
python ps4_aio_server.py --port 8000
pause