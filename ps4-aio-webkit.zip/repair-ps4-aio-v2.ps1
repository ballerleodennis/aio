#requires -Version 5.1
<#
    repair-ps4-aio-v2.ps1

    v2 behebt die Fehler von v1:
      - Wurzelordner wird ueber die Server-Datei bestimmt, nicht ueber $PSScriptRoot
      - faelschlich eingefuegte "cd /d" Zeilen werden aus .py/.ps1 entfernt
      - Launcher-Erkennung nutzt -Filter statt -Include
      - native stderr-Ausgaben brechen das Skript nicht mehr ab
      - Stub wird vor dem Einsatz kompiliert

    Aufruf:
      powershell -ExecutionPolicy Bypass -File .\repair-ps4-aio-v2.ps1
      powershell -ExecutionPolicy Bypass -File .\repair-ps4-aio-v2.ps1 -Root "C:\pfad\zum\projekt"
#>
[CmdletBinding()]
param(
    [string]$Root,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$script:Fail = 0

function Step($m) { Write-Host "`n[*] $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "    [ok]   $m" -ForegroundColor Green }
function Warn($m) { Write-Host "    [warn] $m" -ForegroundColor Yellow }
function Bad($m)  { Write-Host "    [fail] $m" -ForegroundColor Red; $script:Fail++ }

function Read-TextFile([string]$P) { [System.IO.File]::ReadAllText($P) }
function Write-TextFile([string]$P, [string]$T) {
    [System.IO.File]::WriteAllText($P, $T, (New-Object System.Text.UTF8Encoding($false)))
}
function Invoke-Py([string]$Exe, [string[]]$Args) {
    $eap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $o = & $Exe @Args 2>&1 | Out-String
        return [pscustomobject]@{ Code = $LASTEXITCODE; Out = $o.Trim() }
    }
    finally { $ErrorActionPreference = $eap }
}
function Backup([string]$P) {
    $b = "$P." + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.bak'
    Copy-Item -LiteralPath $P -Destination $b -Force
    return $b
}

# ------------------------------------------------------- 1. Wurzel bestimmen
Step "Projektordner bestimmen"

$cands = New-Object System.Collections.Generic.List[string]
if ($Root)          { $cands.Add($Root) }
$cands.Add((Get-Location).Path)
if ($PSScriptRoot)  { $cands.Add($PSScriptRoot) }
$cands.Add((Join-Path $HOME 'Pictures\ps4-aio'))
$cands.Add((Join-Path $HOME 'Documents\WindowsPowerShell'))

$hits = @()
foreach ($c in ($cands | Where-Object { $_ } | Select-Object -Unique)) {
    if (-not (Test-Path -LiteralPath $c -PathType Container)) { continue }
    $s = Join-Path $c 'ps4_aio_server.py'
    if (Test-Path -LiteralPath $s -PathType Leaf) {
        $hits += [pscustomobject]@{ Dir = (Resolve-Path -LiteralPath $c).Path; Server = $s
                                    Mod = (Get-Item -LiteralPath $s).LastWriteTime }
    }
}

if (-not $hits) {
    Warn "keiner der Standardpfade enthaelt ps4_aio_server.py - suche unter $HOME"
    $deep = Get-ChildItem -LiteralPath $HOME -Filter 'ps4_aio_server.py' -File -Recurse -Depth 4 -ErrorAction SilentlyContinue
    foreach ($d in $deep) {
        $hits += [pscustomobject]@{ Dir = $d.DirectoryName; Server = $d.FullName; Mod = $d.LastWriteTime }
    }
}

if (-not $hits) { Bad "ps4_aio_server.py nirgends gefunden. -Root angeben."; exit 1 }

if ($hits.Count -gt 1) {
    Warn "$($hits.Count) Fundstellen - nehme die zuletzt geaenderte:"
    $hits | ForEach-Object { Write-Host "        $($_.Server)  $($_.Mod)" -ForegroundColor DarkGray }
}
$pick = $hits | Sort-Object Mod -Descending | Select-Object -First 1
$Root   = $pick.Dir
$Server = $pick.Server

if ($Root -ne (Get-Location).Path) {
    Warn "Achtung: weicht vom aktuellen Verzeichnis ab"
    Warn "  aktuell : $((Get-Location).Path)"
}
Ok "Projekt : $Root"

$Py = $null
foreach ($c in @('python', 'py')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $Py = $cmd.Source; break }
}
if ($Py) { Ok "Python  : $Py" } else { Warn "kein Python gefunden" }

# ------------------------------------ 2. Schaden aus v1 in .py/.ps1 bereinigen
Step "cd /d-Reste aus Code-Dateien entfernen"
$pat = '^\uFEFF?\s*cd\s+/d\s+"?%~dp0"?\s*(\r?\n)'
$cleaned = 0
foreach ($f in (Get-ChildItem -LiteralPath $Root -File | Where-Object { $_.Extension -in '.py', '.ps1' })) {
    $t = Read-TextFile $f.FullName
    if ($t -match $pat) {
        $b = Backup $f.FullName
        Write-TextFile $f.FullName ($t -replace $pat, '')
        Ok "bereinigt: $($f.Name)  (Backup: $(Split-Path -Leaf $b))"
        $cleaned++
    }
}
if ($cleaned -eq 0) { Ok "nichts zu bereinigen" }

# ------------------------------------------------------------ 3. Modul holen
Step "make_manifest.py sicherstellen"
$Target = Join-Path $Root 'make_manifest.py'

$needStub = $false
if (Test-Path -LiteralPath $Target -PathType Leaf) {
    if ($Py) {
        $r = Invoke-Py $Py @('-m', 'py_compile', $Target)
        if ($r.Code -ne 0) {
            Warn "vorhandene Datei kompiliert nicht - wird ersetzt"
            Warn ($r.Out -split "`n" | Select-Object -First 3 | Out-String).Trim()
            $needStub = $true
        } else { Ok "vorhanden und syntaktisch ok" }
    } else { Ok "vorhanden (keine Pruefung ohne Python)" }
}
else {
    Warn "fehlt - suche im Umfeld"
    $found = Get-ChildItem -LiteralPath (Split-Path -Parent $Root) -Filter 'make_manifest.py' -File -Recurse -Depth 2 -ErrorAction SilentlyContinue |
             Where-Object { $_.FullName -ne $Target } | Select-Object -First 1
    if ($found) {
        Copy-Item -LiteralPath $found.FullName -Destination $Target -Force
        Ok "zurueckgeholt aus $($found.DirectoryName)"
    }
    else { Warn "nirgends gefunden - Platzhalter noetig"; $needStub = $true }
}

if ($needStub) {
    Step "Platzhalter schreiben"
    $src = Read-TextFile $Server
    $attrs = [regex]::Matches($src, 'make_manifest\.([A-Za-z_]\w*)') |
             ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique
    if ($attrs) { Warn ("referenziert: " + ($attrs -join ', ')) } else { Warn "keine Aufrufe gefunden" }

    $L = New-Object System.Collections.Generic.List[string]
    $L.Add('# make_manifest.py - Platzhalter von repair-ps4-aio-v2.ps1')
    $L.Add('# Durch das Original ersetzen, sobald wieder vorhanden.')
    $L.Add('import hashlib, json, os')
    $L.Add('')
    $L.Add('MANIFEST = "manifest.json"')
    $L.Add('')
    $L.Add('def build(base="."):')
    $L.Add('    entries = []')
    $L.Add('    for name in sorted(os.listdir(base)):')
    $L.Add('        p = os.path.join(base, name)')
    $L.Add('        if not os.path.isfile(p) or name == MANIFEST:')
    $L.Add('            continue')
    $L.Add('        with open(p, "rb") as fh:')
    $L.Add('            entries.append({"name": name, "size": os.path.getsize(p),')
    $L.Add('                            "sha256": hashlib.sha256(fh.read()).hexdigest()})')
    $L.Add('    data = {"files": entries}')
    $L.Add('    with open(os.path.join(base, MANIFEST), "w") as fh:')
    $L.Add('        json.dump(data, fh, indent=2)')
    $L.Add('    return data')
    $L.Add('')
    foreach ($a in $attrs) {
        if ($a -eq 'build') { continue }
        $L.Add("def $a(base=`".`"):")
        $L.Add('    return build(base)')
        $L.Add('')
    }
    $L.Add('if __name__ == "__main__":')
    $L.Add('    print(build())')

    if (Test-Path -LiteralPath $Target) { Backup $Target | Out-Null }
    Write-TextFile $Target ($L -join "`r`n")

    if ($Py) {
        $r = Invoke-Py $Py @('-m', 'py_compile', $Target)
        if ($r.Code -eq 0) { Ok "Platzhalter geschrieben und kompiliert" }
        else { Bad "Platzhalter kompiliert nicht: $($r.Out)" }
    } else { Ok "Platzhalter geschrieben" }
}

# ------------------------------------------------------------ 4. Server patch
Step "ps4_aio_server.py patchen"
$text = Read-TextFile $Server
$nl   = if ($text -match "`r`n") { "`r`n" } else { "`n" }
$lines = [System.Collections.Generic.List[string]]($text -split "`r?`n")

$mStart = '# >>> PS4-AIO sys.path bootstrap'
$mEnd   = '# <<< PS4-AIO sys.path bootstrap'
$hasBoot = ($lines | Where-Object { $_ -like "$mStart*" }).Count -gt 0

$idx = -1
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*(import\s+make_manifest\b|from\s+make_manifest\s+import\b)') { $idx = $i; break }
}

if ($idx -lt 0) { Warn "keine Importzeile gefunden - uebersprungen" }
elseif ($hasBoot -and -not $Force) { Ok "Bootstrap liegt schon vor - uebersprungen" }
else {
    $b = Backup $Server
    Ok "Backup: $(Split-Path -Leaf $b)"
    $ind = ([regex]::Match($lines[$idx], '^\s*')).Value
    $orig = $lines[$idx]

    $boot = @(
        "$mStart (repair-ps4-aio-v2.ps1)",
        'import os as _os, sys as _sys',
        '_HERE = _os.path.dirname(_os.path.abspath(__file__))',
        'for _p in (_HERE, _os.path.join(_HERE, "lib"), _os.path.join(_HERE, "tools"),',
        '           _os.path.join(_HERE, "src"), _os.path.dirname(_HERE)):',
        '    if _os.path.isdir(_p) and _p not in _sys.path:',
        '        _sys.path.insert(0, _p)',
        $mEnd
    )

    if ($orig -match '^from\s+make_manifest\s+import\s+(.+)$') {
        $names = ($Matches[1] -split ',' | ForEach-Object { $_.Trim() })
        $join  = $names -join ', '
        $guard = @('try:', "${ind}    from make_manifest import $join", 'except ModuleNotFoundError:',
                   "${ind}    make_manifest = None",
                   "${ind}    " + (($names | ForEach-Object { 'None' }) -join ', '),
                   "${ind}    print(`"[warn] make_manifest fehlt - Manifest deaktiviert`")")
        Warn "Aufrufstellen pruefen: $join"
    }
    else {
        $guard = @('try:', "${ind}    import make_manifest", 'except ModuleNotFoundError:',
                   "${ind}    make_manifest = None",
                   "${ind}    print(`"[warn] make_manifest fehlt - Manifest deaktiviert`")")
    }

    $lines.RemoveAt($idx)
    $lines.InsertRange($idx, [string[]]$guard)
    $lines.InsertRange($idx, [string[]]$boot)
    Write-TextFile $Server ($lines -join $nl)
    Ok "Bootstrap + Guard eingesetzt (Zeile $($idx + 1))"
}

# ------------------------------------------------------------- 5. Launcher
Step "Batch-Launcher pruefen"
$bats = @()
$bats += Get-ChildItem -LiteralPath $Root -Filter '*.bat' -File -ErrorAction SilentlyContinue
$bats += Get-ChildItem -LiteralPath $Root -Filter '*.cmd' -File -ErrorAction SilentlyContinue

if (-not $bats) { Warn "keine .bat/.cmd im Projektordner" }
foreach ($l in $bats) {
    $c = Read-TextFile $l.FullName
    if ($c -match '(?im)^\s*cd\s+/d\s+"?%~dp0') { Ok "$($l.Name): vorhanden"; continue }
    $b = Backup $l.FullName
    Write-TextFile $l.FullName ('cd /d "%~dp0"' + "`r`n" + $c)
    Ok "$($l.Name): cd /d ergaenzt (Backup: $(Split-Path -Leaf $b))"
}

# ----------------------------------------------------------- 6. Verifikation
Step "Verifikation"
if (-not $Py) { Warn "ohne Python keine Pruefung" }
else {
    Push-Location $Root
    try {
        $r1 = Invoke-Py $Py @('-c', 'import make_manifest; print(make_manifest.__file__)')
        if ($r1.Code -eq 0) { Ok "Import: $($r1.Out)" } else { Bad "Import: $($r1.Out)" }

        $r2 = Invoke-Py $Py @('-m', 'py_compile', $Server)
        if ($r2.Code -eq 0) { Ok "Syntax: kompiliert" } else { Bad "Syntax: $($r2.Out)" }

        $r3 = Invoke-Py $Py @('-c', 'import ast; ast.parse(open("ps4_aio_server.py", encoding="utf-8").read()); print("ok")')
        if ($r3.Code -eq 0) { Ok "AST: parsebar" } else { Bad "AST: $($r3.Out)" }
    }
    finally { Pop-Location }
}

Step "Fertig"
if ($script:Fail -eq 0) {
    Write-Host "    Alles gruen. Ordner: $Root" -ForegroundColor Green
    Write-Host "    Server starten, Option 4 (Zertifikat) falls 8443 noch keins hat, dann Option 3." -ForegroundColor DarkGray
    exit 0
}
Write-Host "    $($script:Fail) Punkt(e) offen." -ForegroundColor Red
exit 1