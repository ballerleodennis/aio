@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title PS4 AIO Server
for %%d in (logs payloads chains reports certs) do if not exist "%%d" md "%%d"
python --version >nul 2>&1 || (echo Python fehlt im PATH! & pause & exit /b 1)

echo.
echo   1  HTTP          Port 8000
echo   2  HTTPS         Port 8443  + Zertifikat
echo   3  HTTPS+HTTP    8443 / 8000
echo   4  Zertifikat neu erzeugen
echo   5  HTTP + Watch   Port 8000, Auto-Rebuild bei chains.json-Aenderung
echo.
set /p c=Wahl: 

if "%c%"=="1" python ps4_aio_server.py --port 8000
if "%c%"=="2" python ps4_aio_server.py --port 8443 --tls
if "%c%"=="3" python ps4_aio_server.py --port 8443 --tls --also-http 8000
if "%c%"=="4" python ps4_aio_server.py --regen-cert --no-fetch --no-listener
if "%c%"=="5" python ps4_aio_server.py --port 8000 --watch
pause