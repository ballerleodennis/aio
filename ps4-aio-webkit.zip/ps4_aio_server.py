#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PS4 AIO Exploit Host & Lab Server v1.1
--------------------------------------
+ TLS mit selbstsigniertem Zertifikat (--tls), optional paralleler HTTP-Port
+ AppCache-Manifest mit Server-Injection fuer PS4-Requests
+ Offline-Bundle als ZIP, Cache-Warming-Liste
+ Repo-Watcher: erkennt Upstream-Aenderungen, rebuildt Ketten automatisch
+ Offset-Gegenprobe 14.02 (1402_offsets.txt vs. ps4_offsets.js)
"""
import argparse, hashlib, io, json, os, re, shutil, socket, ssl
import subprocess, sys, threading, time, zipfile
from collections import deque
from datetime import datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
from urllib.request import urlopen, Request

import tls_cert
# >>> PS4-AIO sys.path bootstrap (repair-ps4-aio.ps1) import os as _os, sys as _sys _HERE = _os.path.dirname(_os.path.abspath(__file__)) for _p in (_HERE, _os.path.join(_HERE, "lib"), _os.path.join(_HERE, "tools"),            _os.path.join(_HERE, "src"), _os.path.dirname(_HERE)):     if _os.path.isdir(_p) and _p not in _sys.path:         _sys.path.insert(0, _p) # <<< PS4-AIO sys.path bootstrap
try:
    import make_manifest
except ModuleNotFoundError:
    make_manifest = None
    print("[warn] make_manifest fehlt - Manifest-Funktionen deaktiviert")
import offset_diff
import watcher

ROOT     = os.path.dirname(os.path.abspath(__file__))
CHAINS   = os.path.join(ROOT, "chains")
PAYLOADS = os.path.join(ROOT, "payloads")
LOGS     = os.path.join(ROOT, "logs")
REPORTS  = os.path.join(ROOT, "reports")
for d in (CHAINS, PAYLOADS, LOGS, REPORTS):
    os.makedirs(d, exist_ok=True)

ATTEMPT_LOG = os.path.join(LOGS, "attempts.jsonl")
HIT_LOG     = os.path.join(LOGS, "hits.jsonl")
START_TS    = time.time()
STATE       = {"tls": False, "port": 8000}

RING, RING_L = deque(maxlen=600), threading.Lock()
SSE, SSE_L   = [], threading.Lock()

MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
        ".bin": "application/octet-stream", ".elf": "application/octet-stream",
        ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml",
        ".wasm": "application/wasm", ".ico": "image/x-icon",
        ".md": "text/plain; charset=utf-8", ".appcache": "text/cache-manifest"}


# ----------------------------------------------------------------------------- log
def emit(kind, msg, **extra):
    rec = {"t": datetime.now().strftime("%H:%M:%S"), "ts": time.time(),
           "kind": kind, "msg": msg}
    rec.update(extra)
    line = json.dumps(rec, ensure_ascii=False)
    with RING_L:
        RING.append(rec)
    try:
        open(ATTEMPT_LOG, "a", encoding="utf-8").write(line + "\n")
    except OSError:
        pass
    with SSE_L:
        for q in list(SSE):
            try:
                q.append(rec)
            except Exception:
                SSE.remove(q)
    print(f"[{rec['t']}] {kind:<8} {msg}")


def ring_snapshot(n=200):
    with RING_L:
        return list(RING)[-n:]


# ------------------------------------------------------------------------- payloads
def list_payloads():
    out = []
    for f in sorted(os.listdir(PAYLOADS)):
        p = os.path.join(PAYLOADS, f)
        if os.path.isfile(p):
            blob = open(p, "rb").read()
            out.append({"name": f, "size": len(blob),
                        "md5": hashlib.md5(blob).hexdigest(),
                        "mtime": int(os.stat(p).st_mtime)})
    return out


def store_payload(name, blob):
    name = os.path.basename(name).replace("..", "_") or "payload.bin"
    open(os.path.join(PAYLOADS, name), "wb").write(blob)
    emit("payload", f"gespeichert: {name} ({len(blob)} B, md5 {hashlib.md5(blob).hexdigest()[:8]})")


# --------------------------------------------------------------------------- chains
def load_db():
    try:
        return json.load(open(os.path.join(ROOT, "chains.json"), encoding="utf-8"))
    except Exception as e:
        emit("error", f"chains.json: {e}")
        return {"chains": [], "discovered": []}


def chain_files(cid):
    d = os.path.join(CHAINS, cid)
    if not os.path.isdir(d):
        return []
    return sorted(os.path.relpath(os.path.join(b, f), d).replace("\\", "/")
                  for b, _, fs in os.walk(d) for f in fs)


def fetch_repo(repo, cid, branch=None):
    dest, tmp = os.path.join(CHAINS, cid), os.path.join(CHAINS, cid + ".zip")
    urls = [f"https://codeload.github.com/{repo}/zip/refs/heads/{b}"
            for b in ([branch] if branch else []) + ["main", "master"]]
    last = None
    for u in urls:
        try:
            open(tmp, "wb").write(urlopen(Request(u, headers={"User-Agent": "ps4-aio/1.1"}),
                                          timeout=45).read())
            last = None
            break
        except Exception as e:
            last = e
    if last:
        emit("error", f"download {repo}: {last}")
        return False
    try:
        if os.path.isdir(dest):
            shutil.rmtree(dest)
        os.makedirs(dest, exist_ok=True)
        with zipfile.ZipFile(tmp) as z:
            z.extractall(dest)
        sub = [x for x in os.listdir(dest) if os.path.isdir(os.path.join(dest, x))]
        if len(sub) == 1:
            inner = os.path.join(dest, sub[0])
            for i in os.listdir(inner):
                shutil.move(os.path.join(inner, i), os.path.join(dest, i))
            os.rmdir(inner)
        os.remove(tmp)
        emit("chain", f"{cid}: {len(chain_files(cid))} Dateien entpackt")
        return True
    except Exception as e:
        emit("error", f"entpacken {cid}: {e}")
        return False


def guess_entry(cid):
    fs = [f for f in chain_files(cid) if f.endswith(".js")]
    pr = re.compile(r"(exploit|afterglow|lapse|netctrl|relapse|slopkit|psfree|main|index)", re.I)
    fs.sort(key=lambda f: (0 if pr.search(f) else 1,
                           -os.path.getsize(os.path.join(CHAINS, cid, f))))
    return fs


# ------------------------------------------------------------------------- offline
def offline_bundle(fw):
    db = load_db()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in ("exploit.html", "index.html", "cache.appcache"):
            p = os.path.join(ROOT, f)
            if os.path.isfile(p):
                z.write(p, f)
        for ch in db.get("chains", []):
            if fw not in (ch.get("firmware") or []) and not ch.get("test_14_02"):
                continue
            d = os.path.join(CHAINS, ch["id"])
            for rel in chain_files(ch["id"]):
                z.write(os.path.join(d, rel), f"chains/{ch['id']}/{rel}")
        for p in list_payloads():
            z.write(os.path.join(PAYLOADS, p["name"]), f"payloads/{p['name']}")
        z.writestr("README.txt",
                   f"PS4 AIO Offline-Bundle fw{fw}\n"
                   "Entpackt ablegen, mit beliebigem Static-Server ausliefern.\n"
                   "Reihenfolge: index.html -> exploit.html -> Auto-Chain.\n")
    emit("offline", f"Bundle fw{fw} erzeugt")
    return buf.getvalue()


def warm_list(fw):
    db = load_db()
    urls = ["/exploit.html"]
    for ch in db.get("chains", []):
        if fw not in (ch.get("firmware") or []) and not ch.get("test_14_02"):
            continue
        urls += [f"/chains/{ch['id']}/{f}" for f in chain_files(ch["id"])]
    return urls


# -------------------------------------------------------------------------- scanner
def scan_lan():
    emit("scan", "LAN-Scan")
    ips = []
    try:
        cmd = ["arp", "-a"] if os.name == "nt" else ["ip", "neigh"]
        ips = list(dict.fromkeys(re.findall(
            r"(\d{1,3}(?:\.\d{1,3}){3})",
            subprocess.run(cmd, capture_output=True, text=True, timeout=15).stdout)))
    except Exception as e:
        emit("error", f"arp: {e}")
    found = []
    for ip in ips:
        if ip.startswith(("127.", "0.", "255.")):
            continue
        for port in (9295, 80, 8080, 443):
            s = socket.socket(); s.settimeout(0.35)
            try:
                if s.connect_ex((ip, port)) == 0:
                    found.append({"ip": ip, "port": port}); break
            finally:
                s.close()
    for f in found:
        emit("scan", f"Host {f['ip']}:{f['port']}", **f)
    return found


# ---------------------------------------------------------------- payload listener
def payload_listener(port=9020):
    srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", port)); srv.listen(8)
    emit("net", f"Payload-Listener :{port}")
    while True:
        try:
            c, a = srv.accept()
        except OSError:
            return
        threading.Thread(target=_recv_payload, args=(c, a), daemon=True).start()


def _recv_payload(c, addr):
    c.settimeout(20)
    try:
        head = b""
        while b"\r\n\r\n" not in head:
            ch = c.recv(4096)
            if not ch:
                break
            head += ch
        hdr, _, rest = head.partition(b"\r\n\r\n")
        h = hdr.decode("latin-1", "replace")
        clen = int((re.search(r"content-length:\s*(\d+)", h, re.I) or [0, 0])[1])
        body = bytearray(rest)
        while len(body) < clen:
            ch = c.recv(65536)
            if not ch:
                break
            body += ch
        blob = bytes(body)
        if blob:
            fm = re.search(r'filename="?([^"\r\n;]+)', h, re.I)
            nm = fm.group(1) if fm else (f"recv-{int(time.time())}"
                                        + (".elf" if blob[:4] == b"\x7fELF" else ".bin"))
            store_payload(nm, blob)
            emit("payload", f"von {addr[0]}: {nm} ({len(blob)} B)")
        c.sendall(b"HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\n"
                  b"Content-Length: 2\r\n\r\nOK")
    except Exception as e:
        emit("error", f"recv: {e}")
    finally:
        try: c.close()
        except Exception: pass


# ---------------------------------------------------------------------------- http
class Handler(SimpleHTTPRequestHandler):
    server_version = "PS4AIO/1.1"
    protocol_version = "HTTP/1.1"

    def log_message(self, *a): pass

    def _json(self, obj, code=200):
        raw = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _raw(self, raw, ctype, cache="no-store, must-revalidate"):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", cache)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def _body(self, limit=64 << 20):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(min(n, limit)) if n else b""

    def _ua_fw(self):
        m = re.search(r"PlayStation\s*4\s*([\d.]+)", self.headers.get("User-Agent", ""), re.I)
        return m.group(1) if m else None

    # ------------------------------------------------------------------ GET
    def do_GET(self):
        p = urlparse(self.path).path
        q = parse_qs(urlparse(self.path).query)

        if p == "/api/status":
            db = load_db()
            return self._json({"uptime": int(time.time() - START_TS),
                               "chains": db.get("chains", []),
                               "discovered": db.get("discovered", []),
                               "payloads": list_payloads(),
                               "host": self.headers.get("Host", "localhost"),
                               "watch": watcher.info(),
                               "tls": STATE["tls"], "port": STATE["port"]})
        if p == "/api/log":
            return self._json(ring_snapshot(int((q.get("limit") or ["200"])[0])))
        if p == "/api/chains":
            out = []
            for ch in load_db().get("chains", []):
                fs = chain_files(ch["id"])
                out.append({**ch, "files": fs, "installed": bool(fs),
                            "guess": guess_entry(ch["id"])[:6] if fs else []})
            return self._json(out)
        if p == "/api/payloads":
            return self._json(list_payloads())
        if p == "/api/report":
            fs = sorted(os.listdir(REPORTS), reverse=True)
            if not fs:
                return self._json({"file": None, "body": ""})
            return self._json({"file": fs[0], "body": open(
                os.path.join(REPORTS, fs[0]), encoding="utf-8", errors="replace").read()[:400000]})
        if p == "/api/events":
            return self._sse()
        if p == "/api/watch":
            return self._json(watcher.info())
        if p == "/api/watch/report":
            fs = sorted((f for f in os.listdir(REPORTS) if f.startswith("watch-")), reverse=True)
            if not fs:
                return self._json({"file": None, "body": ""})
            return self._json({"file": fs[0], "body": open(
                os.path.join(REPORTS, fs[0]), encoding="utf-8", errors="replace").read()[:200000]})
        if p == "/api/offsetdiff":
            fs = sorted((f for f in os.listdir(REPORTS)
                         if f.startswith("offsetdiff-") and f.endswith(".html")), reverse=True)
            if not fs:
                return self._json({"file": None})
            return self._raw(open(os.path.join(REPORTS, fs[0]), "rb").read(),
                             "text/html; charset=utf-8")
        if p == "/api/scan":
            return self._json(scan_lan())
        if p == "/api/warm":
            return self._json(warm_list((q.get("fw") or ["14.02"])[0]))
        if p == "/api/bundle":
            fw = (q.get("fw") or ["14.02"])[0]
            return self._raw(offline_bundle(fw), "application/zip")
        if p == "/cache.appcache":
            fw = (q.get("fw") or [self._ua_fw() or "14.02"])[0]
            body, _ = make_manifest.build(fw)
            return self._raw(body.encode(), "text/cache-manifest")
        if p == "/certs/cert.pem":
            cp = os.path.join(ROOT, "certs", "cert.pem")
            if os.path.isfile(cp):
                return self._raw(open(cp, "rb").read(), "application/x-pem-file")
        return self._static(p)

    # ----------------------------------------------------------------- POST
    def do_POST(self):
        p = urlparse(self.path).path
        if p == "/api/log":
            try: d = json.loads(self._body() or b"{}")
            except Exception: d = {}
            emit(d.get("kind", "client"), d.get("msg", ""), fw=d.get("fw"),
                 chain=d.get("chain"), stage=d.get("stage"),
                 ua=(d.get("ua") or "")[:200], ip=self.client_address[0])
            return self._json({"ok": True})
        if p == "/api/upload":
            ct = self.headers.get("Content-Type", "")
            raw = self._body()
            if "boundary=" in ct:
                bnd = ct.split("boundary=")[1].strip().strip('"').encode()
                for part in raw.split(b"--" + bnd):
                    if b"filename=" in part:
                        nm = re.search(rb'filename="([^"]+)"', part)
                        data = part.split(b"\r\n\r\n", 1)[1].rsplit(b"\r\n", 1)[0]
                        store_payload(nm.group(1).decode("latin-1") if nm else "upload.bin", data)
                        return self._json({"ok": True})
            store_payload("upload.bin", raw)
            return self._json({"ok": True})
        if p == "/api/fetch":
            db = load_db()
            def job():
                for ch in db.get("chains", []):
                    if ch.get("repo"):
                        fetch_repo(ch["repo"], ch["id"], ch.get("branch"))
                emit("chain", "fetch fertig")
            threading.Thread(target=job, daemon=True).start()
            return self._json({"ok": True})
        if p == "/api/analyze":
            def job():
                try:
                    import ps4_analyzer
                    ps4_analyzer.run(emit)
                except Exception as e:
                    emit("error", f"analyzer: {e}")
            threading.Thread(target=job, daemon=True).start()
            return self._json({"ok": True})
        if p == "/api/offsetdiff":
            def job():
                try:
                    offset_diff.run(emit)
                except Exception as e:
                    emit("error", f"offsetdiff: {e}")
            threading.Thread(target=job, daemon=True).start()
            return self._json({"ok": True})
        if p == "/api/kernel-ok":
            try: d = json.loads(self._body() or b"{}")
            except Exception: d = {}
            emit("kernel", f"KERNEL (fw {d.get('fw')}, chain {d.get('chain')})",
                 ip=self.client_address[0], **d)
            open(os.path.join(LOGS, "wins.jsonl"), "a", encoding="utf-8").write(
                json.dumps({"ts": time.time(), **d}) + "\n")
            return self._json({"ok": True})
        if p == "/api/watch/toggle":
            if watcher.info()["active"]:
                watcher.stop()
                emit("watch", "deaktiviert")
                return self._json({"ok": True, "active": False})
            _watch_start()
            return self._json({"ok": True, "active": True})
        if p == "/api/watch/rebuild":
            try:
                fws = json.loads(self._body() or b"{}").get("firmware") or []
            except Exception:
                fws = []
            emit("watch", "manueller Rebuild " + (", ".join(fws) or "alle"))
            watcher.force(*fws)
            return self._json({"ok": True, "queued": watcher.info()["pending"]})
        return self._json({"error": "not found"}, 404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()

    # ------------------------------------------------------------------ SSE
    def _sse(self):
        q = deque(maxlen=400)
        with SSE_L:
            SSE.append(q)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            for old in ring_snapshot(50):
                self.wfile.write(f"data: {json.dumps(old)}\n\n".encode())
            self.wfile.flush()
            last = time.time()
            while True:
                while q:
                    self.wfile.write(f"data: {json.dumps(q.popleft())}\n\n".encode())
                    self.wfile.flush()
                if time.time() - last > 15:
                    self.wfile.write(b": ping\n\n"); self.wfile.flush(); last = time.time()
                time.sleep(0.25)
        except Exception:
            pass
        finally:
            with SSE_L:
                if q in SSE:
                    SSE.remove(q)

    # ---------------------------------------------------------------- static
    def _static(self, path):
        rel = unquote(path).lstrip("/") or "index.html"
        full = os.path.normpath(os.path.join(ROOT, rel))
        if not full.startswith(ROOT):
            return self._json({"error": "forbidden"}, 403)

        if os.path.isdir(full):
            idx = os.path.join(full, "index.html")
            if os.path.isfile(idx):
                full = idx
            else:
                items = sorted(os.listdir(full))
                body = ("<meta charset=utf-8><body style='background:#0b0e13;color:#c9d4e3;"
                        "font:14px monospace;padding:2rem'><h3>Index " + rel +
                        "</h3><ul>" + "".join(
                            f"<li><a style='color:#5cc8ff' href='/{rel}/{i}'>{i}</a></li>"
                            for i in items) + "</ul>")
                return self._raw(body.encode(), "text/html; charset=utf-8")

        if not os.path.isfile(full):
            emit("hit", f"404 {rel}", ip=self.client_address[0])
            return self._json({"error": "not found"}, 404)

        ext = os.path.splitext(full)[1].lower()
        data = open(full, "rb").read()

        # AppCache-Manifest in die Seite injizieren (nur PS4-Browser)
        if ext == ".html":
            fw = self._ua_fw()
            if fw:
                man = f'/cache.appcache?fw={fw}'
                txt = data.decode("utf-8", "replace")
                if "<html" in txt and "manifest=" not in txt:
                    txt = re.sub(r"<html([^>]*)>",
                                 lambda m: f'<html{m.group(1)} manifest="{man}">',
                                 txt, count=1)
                    data = txt.encode()
                emit("cache", f"manifest injiziert ({fw}) an {self.client_address[0]}")
            emit("hit", f"{rel} an {self.client_address[0]} ({len(data)} B)")
            try:
                open(HIT_LOG, "a", encoding="utf-8").write(json.dumps(
                    {"ts": time.time(), "path": rel, "ip": self.client_address[0],
                     "ua": self.headers.get("User-Agent", "")}) + "\n")
            except OSError:
                pass

        self.send_response(200)
        self.send_header("Content-Type", MIME.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(data)


# ---------------------------------------------------------------------------- main
def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def _watch_start():
    ctx = {"emit": emit, "load_db": load_db, "save_db": lambda db: json.dump(
               db, open(os.path.join(ROOT, "chains.json"), "w", encoding="utf-8"),
               indent=2, ensure_ascii=False),
           "chain_files": chain_files, "fetch_repo": fetch_repo,
           "guess_entry": guess_entry, "offline_bundle": offline_bundle,
           "build_manifest": make_manifest.build}
    return watcher.start(ctx)


def serve(port, tls=False, also_http=None):
    ip = lan_ip()
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    if tls:
        cert, key = tls_cert.ensure(ips=[int(x) for x in ip.split(".")])
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert, key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        STATE["tls"] = True
        emit("boot", "TLS aktiv", cert=cert)
    STATE["port"] = port

    scheme = "https" if tls else "http"
    print(f"\n  PS4 Browser:  {scheme}://{ip}:{port}/exploit.html")
    print(f"  Dashboard:    {scheme}://{ip}:{port}/")
    if tls:
        print(f"  Zertifikat:   {scheme}://{ip}:{port}/certs/cert.pem  (auf PS4 importieren)\n")
    else:
        print()

    if also_http:
        def second():
            s2 = ThreadingHTTPServer(("0.0.0.0", also_http), Handler)
            emit("boot", f"Zusatz-HTTP auf :{also_http}")
            s2.serve_forever()
        threading.Thread(target=second, daemon=True).start()

    srv.serve_forever()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--tls", action="store_true")
    ap.add_argument("--also-http", type=int, default=None)
    ap.add_argument("--no-fetch", action="store_true")
    ap.add_argument("--no-listener", action="store_true")
    ap.add_argument("--regen-cert", action="store_true")
    ap.add_argument("--watch", action="store_true")
    ap.add_argument("--watch-interval", type=float, default=2.5)
    a = ap.parse_args()

    emit("boot", f"PS4 AIO v1.1 startet (tls={a.tls})")
    if a.regen_cert:
        tls_cert.ensure(ips=[int(x) for x in lan_ip().split(".")], force=True)
        emit("boot", "Zertifikat neu erzeugt")

    if not a.no_listener:
        threading.Thread(target=payload_listener, args=(9020,), daemon=True).start()

    db = load_db()
    if not a.no_fetch:
        def boot_fetch():
            time.sleep(1.5)
            for ch in db.get("chains", []):
                if ch.get("repo") and not chain_files(ch["id"]):
                    fetch_repo(ch["repo"], ch["id"], ch.get("branch"))
        threading.Thread(target=boot_fetch, daemon=True).start()

    if a.watch:
        watcher.STATE["interval"] = a.watch_interval
        _watch_start()
        emit("boot", f"Watch aktiv ({a.watch_interval}s)")

    serve(a.port, a.tls, a.also_http)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nbye")