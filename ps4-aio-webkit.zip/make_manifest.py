# make_manifest.py - Platzhalter, erzeugt von repair-ps4-aio.ps1
# Original ersetzen, sobald wieder verfuegbar.
import hashlib, json, os

MANIFEST = "manifest.json"

def build(base="."):
    entries = []
    for name in sorted(os.listdir(base)):
        p = os.path.join(base, name)
        if not os.path.isfile(p) or name == MANIFEST:
            continue
        with open(p, "rb") as fh:
            entries.append({"name": name,
                            "size": os.path.getsize(p),
                            "sha256": hashlib.sha256(fh.read()).hexdigest()})
    data = {"files": entries}
    with open(os.path.join(base, MANIFEST), "w") as fh:
        json.dump(data, fh, indent=2)
    return data

if __name__ == "__main__":
    print(build())