#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Selbstsigniertes Zertifikat fuer den PS4-Host.
Reihenfolge: cryptography -> openssl-CLI -> reiner Python-DER-Builder.
Schreibt certs/cert.pem + certs/key.pem und erneuert bei geaenderten SAN-IPs.
"""
import base64, hashlib, json, os, random, secrets, shutil, subprocess
from datetime import datetime, timedelta, timezone

CERTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "certs")
META = os.path.join(CERTS, "san.json")

# ------------------------------------------------------------------ DER-Helfer
def _len(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b

def _tlv(tag, body):
    return bytes([tag]) + _len(len(body)) + body

def _seq(*i): return _tlv(0x30, b"".join(i))
def _set(*i): return _tlv(0x31, b"".join(i))
def _null(): return b"\x05\x00"
def _bool(v): return _tlv(0x01, b"\xff" if v else b"\x00")
def _utf8(s): return _tlv(0x0c, s.encode())
def _oct(d): return _tlv(0x04, d)
def _bits(d): return _tlv(0x03, b"\x00" + d)
def _ctx(n, d): return _tlv(0xA0 | n, d)

def _int(v):
    b = v.to_bytes(max(1, (v.bit_length() + 7) // 8), "big")
    if b[0] & 0x80:
        b = b"\x00" + b
    return _tlv(0x02, b)

def _oid(dotted):
    p = [int(x) for x in dotted.split(".")]
    body = bytes([40 * p[0] + p[1]])
    for v in p[2:]:
        if v < 128:
            body += bytes([v])
        else:
            ch = []
            while v:
                ch.insert(0, v & 0x7F)
                v >>= 7
            body += bytes([c | 0x80 for c in ch[:-1]] + [ch[-1]])
    return _tlv(0x06, body)

def _utc(dt):
    return _tlv(0x17, dt.strftime("%y%m%d%H%M%SZ").encode())

# ------------------------------------------------------------------ RSA
_SMALL = [p for p in range(3, 2000) if all(p % d for d in range(2, int(p ** .5) + 1))]

def _prime(bits):
    while True:
        c = random.getrandbits(bits) | (1 << (bits - 1)) | 1
        if any(c % p == 0 for p in _SMALL):
            continue
        d, s = c - 1, 0
        while d % 2 == 0:
            d //= 2; s += 1
        ok = True
        for _ in range(24):
            a = random.randrange(2, c - 1)
            x = pow(a, d, c)
            if x in (1, c - 1):
                continue
            for _ in range(s - 1):
                x = pow(x, 2, c)
                if x == c - 1:
                    break
            else:
                ok = False; break
        if ok:
            return c

def _keypair(bits=2048):
    e = 65537
    while True:
        p, q = _prime(bits // 2), _prime(bits // 2)
        if p == q:
            continue
        phi = (p - 1) * (q - 1)
        if phi % e:
            return p * q, e, pow(e, -1, phi), p, q

def _der_int_pad(v):
    b = v.to_bytes((v.bit_length() + 7) // 8, "big")
    return b"\x00" + b if b[0] & 0x80 else b

# ------------------------------------------------------------------ Builder
def _build(ips, dns, days=3650):
    n, e, d, p, q = _keypair()
    name = _seq(_set(_seq(_oid("2.5.4.3"), _utf8("PS4 AIO"))),
                _set(_seq(_oid("2.5.4.10"), _utf8("PS4 AIO Local"))))
    now = datetime.now(timezone.utc)
    val = _seq(_utc(now - timedelta(days=1)), _utc(now + timedelta(days=days)))
    spki = _seq(_seq(_oid("1.2.840.113549.1.1.1"), _null()),
                _bits(_seq(_int(n), _int(e))))

    san = [_tlv(0x82, h.encode()) for h in dns] + [_tlv(0x87, bytes(ips))]
    exts = _seq(
        _seq(_oid("2.5.29.19"), _bool(True), _oct(_seq(_bool(True)))),
        _seq(_oid("2.5.29.15"), _bool(True), _oct(_tlv(0x03, b"\x05\xa0"))),
        _seq(_oid("2.5.29.17"), _oct(_seq(*san))),
    )
    sigalg = _seq(_oid("1.2.840.113549.1.1.11"), _null())
    tbs = _seq(_ctx(0, _int(2)), _int(secrets.randbits(64)), sigalg,
               name, val, name, spki, _ctx(3, exts))

    digest = hashlib.sha256(tbs).digest()
    di = bytes.fromhex("3031300d060960864801650304020105000420") + digest
    k = (n.bit_length() + 7) // 8
    em = b"\x00\x01" + b"\xff" * (k - len(di) - 3) + b"\x00" + di
    sig = pow(int.from_bytes(em, "big"), d, n).to_bytes(k, "big")
    cert = _seq(tbs, sigalg, _bits(sig))

    def pem(der, label):
        b = base64.b64encode(der).decode()
        return (f"-----BEGIN {label}-----\n"
                + "\n".join(b[i:i + 64] for i in range(0, len(b), 64))
                + f"\n-----END {label}-----\n")

    key = _seq(_int(0), _int(n), _int(e), _int(d), _int(p), _int(q),
               _int(d % (p - 1)), _int(d % (q - 1)), _int(pow(q, -1, p)))
    return pem(cert, "CERTIFICATE"), pem(key, "RSA PRIVATE KEY")

# ------------------------------------------------------------------ Öffentlich
def ensure(ips=(), dns=("ps4-aio.local", "localhost"), force=False):
    os.makedirs(CERTS, exist_ok=True)
    cert, key = os.path.join(CERTS, "cert.pem"), os.path.join(CERTS, "key.pem")
    want = {"ips": sorted(set(list(ips) + [127, 0, 0, 1])), "dns": sorted(dns)}
    want["ips"] = [list(ips)]

    have = None
    if os.path.exists(META):
        try:
            have = json.load(open(META))
        except Exception:
            have = None

    if not force and have == want and os.path.exists(cert) and os.path.exists(key):
        return cert, key

    ipb = [bytes(ips_)[:4] for ips_ in want["ips"]]

    if shutil.which("openssl") and not os.environ.get("AIO_FORCE_PURE"):
        san = ",".join([f"IP:{'.'.join(map(str, i))}" for i in ipb] + [f"DNS:{d}" for d in dns])
        try:
            subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                            "-keyout", key, "-out", cert, "-days", "3650",
                            "-subj", "/CN=PS4 AIO/O=PS4 AIO Local",
                            "-addext", f"subjectAltName={san}",
                            "-addext", "basicConstraints=critical,CA:TRUE"],
                           check=True, capture_output=True, timeout=120)
            json.dump(want, open(META, "w"))
            return cert, key
        except Exception:
            pass

    c, k = _build(ipb, dns)
    open(cert, "w").write(c)
    open(key, "w").write(k)
    os.chmod(key, 0o600)
    json.dump(want, open(META, "w"))
    return cert, key